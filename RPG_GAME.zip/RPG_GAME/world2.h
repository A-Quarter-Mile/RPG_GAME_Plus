#ifndef WORLD2_H
#define WORLD2_H


class world2
{
public:
    world2();
};

#endif // WORLD2_H