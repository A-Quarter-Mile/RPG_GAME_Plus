#include "world2.h"

world2::world2()
{

}
