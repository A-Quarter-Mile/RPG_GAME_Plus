#ifndef WORLD3_H
#define WORLD3_H


class world3
{
public:
    world3();
};

#endif // WORLD3_H